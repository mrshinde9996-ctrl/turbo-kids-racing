TURBO KIDS RACING — Android APK project

Is ZIP mein ek lightweight racing game aur Android WebView wrapper hai.
Game ko phone ke browser mein index.html se test kar sakte hain.

APK banane ke liye (GitHub Actions):
1. ZIP extract karein.
2. GitHub par naya repository banayein: turbo-kids-racing
3. ZIP ke andar ki sabhi files/folders repository ke root mein upload karein (ZIP file ko sirf upload karna kaafi nahi; files extract honi chahiye).
4. Commit changes.
5. Repository ke Actions tab mein "Build Android APK" workflow run/check karein.
6. Build green ho jaaye to workflow run kholein aur Artifacts mein TurboKidsRacing-APK download karein.
7. ZIP extract karke app-debug.apk phone par install karein. Android agar permission maange to trusted APK ke liye install permission allow karein.

Important:
- Yeh debug APK personal testing ke liye hai, Google Play release ke liye signed release AAB aur Play Console setup chahiye.
- APK yahan pehle se compile nahi ki gayi hai. GitHub Actions ko build successful karna hoga.
- Game mein real-money purchase/billing shamil nahi hai; koi payment charge nahi hota.
- 35 MB size target hai, guarantee nahi; actual build ke baad size check karein.
