plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.turbokids.racing"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.turbokids.racing"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
